def author_name():
    return "Ganesh"
def author_education():
    return "Purusing Engineering Pre-final Year"
def author_socialmedia():
    return "https://www.linkedin.com/in/ganeshuthiravasagam/"
def author_github():
    return "https://github.com/Ganeshuthiravasagam/"

